package application;

public enum Owner { NONE, FIRST, SECOND;
	public Owner opposite() {
		return this == SECOND ? FIRST : this == FIRST ? SECOND : NONE;
	}
//	@Override
//    public String toString() {
//        switch (this) {
//            case FIRST:
//                return "X";
//            case SECOND:
//                return "O";
//            default:
//                return "";
//        }
//    }
}