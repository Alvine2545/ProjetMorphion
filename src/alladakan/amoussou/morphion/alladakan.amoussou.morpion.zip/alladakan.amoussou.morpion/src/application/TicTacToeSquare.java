package application;

import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;

import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class TicTacToeSquare extends TextField {

	private static TicTacToeModel model = TicTacToeModel.getInstance();

	private ObjectProperty<Owner> ownerProperty = new SimpleObjectProperty<>(Owner.NONE);

	private BooleanProperty winnerProperty = new SimpleBooleanProperty(false);

	public ObjectProperty<Owner> ownerProperty() {
		return ownerProperty;
	}

	public BooleanProperty winnerProperty() {
		return winnerProperty;
	}

	public TicTacToeSquare(final int row, final int column) {
		// TODO: Initialisation de la case
		// this.ownerProperty = model.getSquare(row, column);
		//this.winnerProperty = model.getWinningSquare(row, column);
		// Lier la propriété ownerProperty avec la propriété correspondante dans le
		// modèle
		ownerProperty.bindBidirectional(model.getSquare(row, column));
		winnerProperty.bind(model.gameOver());
		// Initialiser les propriétés visuelles en fonction des propriétés du modèle
		//setText(ownerProperty.get().toString());
		
		 textProperty().bind(Bindings.when(ownerProperty.isEqualTo(Owner.FIRST))
	                .then("X")
	                .otherwise(Bindings.when(ownerProperty.isEqualTo(Owner.SECOND))
	                        .then("O")
	                        .otherwise("")));
		// Rendre le TextField en lecture seule
		setEditable(false);
		
		
		// Ajout des écouteurs d'événements pour la souris
        setOnMouseEntered(event -> {
            // Vérification si la case est vide et si le jeu n'est pas terminé
            if (model.validSquare(row, column) && !model.gameOver().get()) {
                // Changement de la couleur de fond en vert
                setStyle("-fx-background-color: #00FF00;");
            }else {
            	// Rétablissement de la couleur de fond à rouge
                setStyle("-fx-background-color: #FF0000;");
            }
        });

        setOnMouseExited(event -> {
            	// Initialisation de la couleur de fond à rouge
        	if (model.gameOver().get()) {
                // Changement de la couleur de fond en rouge
                setStyle("-fx-background-color: #FF0000;");
            }else {
                setStyle("-fx-background-color: #FFFFFF;");}
                
        });
        
        
        
     // Liens le style des cases à la propriété gameOver()
//        styleProperty().bind(
//            Bindings.when(model.gameOver())
//                    .then("-fx-background-color: #FF0000;") // Fond rouge
//                    .otherwise("-fx-background-color: white;") // Fond blanc (par défaut)
//        );
        
        
     // Liaison conditionnelle pour changer la couleur lorsque le jeu est terminé
        winnerProperty.addListener((observable, oldValue, newValue) -> {
        	//System.out.println("frfond");
            if (newValue) {
                // Changement de couleur de fond en rouge lorsque le jeu est terminé
                setStyle("-fx-background-color: #FF0000;"); // Fond rouge
                if(model.getWinningSquare(row, column).get()) {
                	setFont(Font.font("System", FontWeight.BOLD, 16));
                }
            }else {
            	setStyle("-fx-background-color: #FFFFFF;");
            }
        });
     
	}
	
	

	

}