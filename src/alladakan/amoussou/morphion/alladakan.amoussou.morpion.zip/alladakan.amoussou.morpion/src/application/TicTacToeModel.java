package application;


import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.NumberExpression;
import javafx.beans.binding.StringExpression;
import javafx.beans.property.*;
//import javafx.beans.property.BooleanProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class TicTacToeModel {
	@FXML
	private Button resartButton;

	/**
	 * Taille du plateau de jeu (pour être extensible).
	 */
	private final static int BOARD_WIDTH = 3;
	private final static int BOARD_HEIGHT = 3;
	/**
	 * Nombre de pièces alignées pour gagner (idem).
	 */
	private final static int WINNING_COUNT = 3;
	
	private IntegerProperty freeCels  = new SimpleIntegerProperty(BOARD_HEIGHT * BOARD_WIDTH);
	
	/**
	 * Joueur courant.
	 */
	private final ObjectProperty<Owner> turn = new SimpleObjectProperty<>(Owner.FIRST);
	/**
	 * Vainqueur du jeu, NONE si pas de vainqueur.
	 */
	private final ObjectProperty<Owner> winner = new SimpleObjectProperty<>(Owner.NONE);
	/**
	 * Plateau de jeu.
	 */
	private final ObjectProperty<Owner>[][] board;
	/**
	 * Positions gagnantes.
	 */
	private final BooleanProperty[][] winningBoard;

	/**
	 * Constructeur privé.
	 */
	private TicTacToeModel() {
		this.board = new ObjectProperty[BOARD_WIDTH][BOARD_HEIGHT];
		this.winningBoard = new BooleanProperty[BOARD_WIDTH][BOARD_HEIGHT];
		restart();

	}

	/**
	 * @return la seule instance possible du jeu.
	 */
	public static TicTacToeModel getInstance() {
		return TicTacToeModelHolder.INSTANCE;
	}

	private static class TicTacToeModelHolder {
		private static final TicTacToeModel INSTANCE = new TicTacToeModel();
	}

	public void restart() {
		System.out.println("vcx");
		// Initialisation du plateau de jeu

		for (int i = 0; i < BOARD_WIDTH; i++) {
			for (int j = 0; j < BOARD_HEIGHT; j++) {
				board[i][j] = new SimpleObjectProperty<>(Owner.NONE);
				winningBoard[i][j] = new SimpleBooleanProperty(false);
			}
		}
		this.turn.set(Owner.FIRST);
		this.winner.set(Owner.NONE);
		this.freeCels.set(BOARD_HEIGHT * BOARD_WIDTH);
	}

	public final ObjectProperty<Owner> turnProperty() {
		return this.turn;
	}

	public final ObjectProperty<Owner> getSquare(int row, int column) {
		return this.board[row][column];
	}

	public final BooleanProperty getWinningSquare(int row, int column) {
		return this.winningBoard[row][column];
	}

	/**
	 * Cette fonction ne doit donner le bon résultat que si le jeu est terminé.
	 * L’affichage peut être caché avant la fin du jeu.
	 *
	 * @return résultat du jeu sous forme de texte
	 */
    public final StringExpression getEndOfGameMessage() { 
    	
    	
    	StringExpression endOfGameMessage = new SimpleStringProperty("");

        // Vérifiez si le jeu est terminé
        if (gameOver().get()) {
            //Owner winner = determineWinner();
            if (winner.get() == Owner.FIRST) {
                endOfGameMessage = new SimpleStringProperty("Game Over: Le gagnant est le premier joueur.");
            }else if (winner.get() == Owner.SECOND) {
            	endOfGameMessage = new SimpleStringProperty("Game Over: Le gagnant est le second joueur.");
            }
            else {
                endOfGameMessage = new SimpleStringProperty("Game Over: Match nul !");
            }
        }

        return endOfGameMessage;
    }

	public void setWinner(Owner winner) {
		this.winner.set(winner);
	}

	public boolean validSquare(int row, int column) {
		return this.board[row][column].get() == Owner.NONE && this.winner.get() == Owner.NONE;
	}

	public void nextPlayer() {
		this.turn.set(this.turn.get().opposite());
	}

	/**
	 * Jouer dans la case (row, column) quand c’est possible.
	 */
	public void play(int row, int column) {
		// Onvérifie si la case est valide
		if (this.validSquare(row, column)) {
			// On mets le joueur courant dans le tableau
			// Avec this.board[row][column] = this.turn; il y a un problème
			this.board[row][column].set(this.turn.get());
			//this.winningBoard[row][column].set(true);
			freeCels.set(freeCels.get()-1);
			// Avant de faire un nextPlayer(), on vérifie s'il y a pas fin de jeu
			if (checkWinner(row, column)) {
				setWinner(turn.get());
			} else if (isBoardFull()) {
				setWinner(Owner.NONE);
			} else {
				this.nextPlayer();
			}
			
		}

	}

	/**
	 * @return true s’il est possible de jouer dans la case c’est-à-dire la case est
	 *         libre et le jeu n’est pas terminé
	 */
	public BooleanBinding legalMove(int row, int column) {
		return Bindings.createBooleanBinding(() -> validSquare(row, column) && this.winner.get() == Owner.NONE,
				this.board[row][column], this.winner);

	}

    public NumberExpression getScore(Owner owner) { 
    	IntegerProperty score = new SimpleIntegerProperty(0);
    	//IntegerProperty a = new SimpleIntegerProperty(0);
        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                if (board[i][j].get() == owner) {
                    score.set(score.get() + 1);
                }
            }
        }
        return score;
    }

	/**
	 * @return true si le jeu est terminé (soit un joueur a gagné, soit il n’y a
	 *         plus de cases à jouer)
	 */
	public BooleanBinding gameOver() {
	    BooleanBinding gameWon = winner.isNotEqualTo(Owner.NONE);
	    BooleanBinding boardFull = Bindings.createBooleanBinding(() -> isBoardFull());
	    return gameWon.or(boardFull);
	}



	private boolean isBoardFull() {
		// Vérifiez si toutes les cases sont remplies
		for (int row = 0; row < BOARD_HEIGHT; row++) {
			for (int col = 0; col < BOARD_WIDTH; col++) {
				if (board[row][col].get() == Owner.NONE) {
					return false;
				}
			}
		}
		return true;
	}

	private boolean checkWinner(int row, int column) {
		Owner player = board[row][column].get();

		// Vérification de la ligne
		boolean rowWin = true;
		for (int col = 0; col < BOARD_WIDTH; col++) {
			if (board[row][col].get() != player) {
				rowWin = false;
				break;
			}
		}

		// Vérification de la colonne
		boolean colWin = true;
		for (int r = 0; r < BOARD_HEIGHT; r++) {
			if (board[r][column].get() != player) {
				colWin = false;
				break;
			}
		}

		// Vérification de la diagonale (si nécessaire)
		boolean diag1Win = true;
		for (int i = 0; i < BOARD_WIDTH; i++) {
			if (board[i][i].get() != player) {
				diag1Win = false;
				break;
			}
		}

		// Vérification de l'autre diagonale (si nécessaire)
		boolean diag2Win = true;
		for (int i = 0; i < BOARD_WIDTH; i++) {
			if (board[i][BOARD_WIDTH - 1 - i].get() != player) {
				diag2Win = false;
				break;
			}
		}

		// Retourne vrai s'il y a un gagnant dans une ligne, colonne ou diagonale
		//return rowWin || colWin || diag1Win || diag2Win;
		
		// Mettre à jour winningBoard si un joueur a gagné
	    if (rowWin || colWin || diag1Win || diag2Win) {
	        if (rowWin) {
	            for (int col = 0; col < BOARD_WIDTH; col++) {
	                winningBoard[row][col].set(true);
	            }
	        }
	        if (colWin) {
	            for (int r = 0; r < BOARD_HEIGHT; r++) {
	                winningBoard[r][column].set(true);
	            }
	        }
	        if (diag1Win) {
	            for (int i = 0; i < BOARD_WIDTH; i++) {
	                winningBoard[i][i].set(true);
	            }
	        }
	        if (diag2Win) {
	            for (int i = 0; i < BOARD_WIDTH; i++) {
	                winningBoard[i][BOARD_WIDTH - 1 - i].set(true);
	            }
	        }
	        return true;
	    }
	    return false;
	}
	
	public IntegerProperty getFreeCells() {
	    return freeCels;
	}


}