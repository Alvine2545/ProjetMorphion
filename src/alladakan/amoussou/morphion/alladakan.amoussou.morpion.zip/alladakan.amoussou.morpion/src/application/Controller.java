package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

public class Controller {
	
	//@FXML private Button btn00;
	@FXML private TextField essai;
	
	@FXML private Button resartButton;
	@FXML private GridPane gridPane;
	
	 private TicTacToeModel model;
	
	 

    @FXML
    private void handleRestartButton(ActionEvent event) {
        // Logique pour redémarrer le jeu ici
        // Par exemple, vous pouvez appeler la méthode restart() de votre TicTacToeModel
        TicTacToeModel.getInstance().restart();
        System.out.println("vcx");
    }
    
    
    
    // Méthode pour initialiser le modèle
    public void initializeModel(TicTacToeModel model) {
        this.model = model;
    }
    
    
    
    @FXML
    private void handleTextFieldButton(MouseEvent event) {
    	TextField clickedTextField = (TextField) event.getSource();
//        int row = Character.getNumericValue(clickedTextField.getId().charAt(0));
//        int column = Character.getNumericValue(clickedTextField.getId().charAt(1));
    	Integer row = GridPane.getRowIndex(clickedTextField);
        Integer column = GridPane.getColumnIndex(clickedTextField);
        System.out.println(event.getSource() +" "+row+" "+column+" Coup non valide !");
        // Assurez-vous que le coup est légal avant de jouer
//        if (model.legalMove(row, column).get()) {
//            model.play(row, column);
//        } else {
//            // Le coup n'est pas légal, vous pouvez afficher un message d'erreur
//            System.out.println("Coup non valide !");
//        }
    }

}
