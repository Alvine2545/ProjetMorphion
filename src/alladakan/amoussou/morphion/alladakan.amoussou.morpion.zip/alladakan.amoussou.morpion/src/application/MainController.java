package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class MainController implements Initializable {
	// @FXML private Button btn00;
	
	@FXML
	private Button resartButton;
	@FXML
	private GridPane gridPane;
	@FXML
	private Label secondCase;
	@FXML
	private Label firstCase;
	
	@FXML
	private Label freeCase;
	@FXML
	private Label winnerTxtf;
	
	private TicTacToeModel model =TicTacToeModel.getInstance();
	private TicTacToeSquare square;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//System.out.println("vbn,");
		// Lier le texte du Label au nombre de cases libres
        freeCase.textProperty().bind(Bindings.format("%d cases libres", model.getFreeCells()));
        winnerTxtf.textProperty().bind(model.getEndOfGameMessage());
		for (int row = 0; row < gridPane.getRowCount(); row++) {
            for (int column = 0; column < gridPane.getColumnCount(); column++) {
                square = new TicTacToeSquare(row, column);
                final int finalRow = row;
                final int finalColumn = column;
                //square.setPrefWidth(10); // Définir la largeur préférée du TextField
                square.setPrefHeight(74);
                square.getStyleClass().add("custom-textfield"); // Ajoutez une classe CSS

                // Ajoutez le gestionnaire d'événements de clic à chaque instance de TicTacToeSquare
                square.setOnMouseClicked(event -> handleSquareClick(finalRow, finalColumn));
             
                gridPane.add(square, column, row);
            }
        }
		

	}
	
	private void handleSquareClick(int row, int column) {
		//System.out.println(row+" "+column+" oui");
		

	    // Vérifiez si le coup est légal
	    if (model.legalMove(row, column).get()) {
	        // Jouez dans la case si le coup est légal
	    	//this.square
	    	//System.out.println(model.turnProperty().get().toString().equals("FIRST"));
	        model.play(row, column);
	        
	        //firstCase.textProperty().bind(model.turnProperty().get().toString());

	        // Style conditionnel en fonction du joueur courant
	        firstCase.styleProperty().bind(
	            Bindings.when(model.turnProperty().isEqualTo(Owner.FIRST))
	            .then("-fx-background-color: cyan;")
	            .otherwise("-fx-background-color: red;"));
	        
	        secondCase.styleProperty().bind(
		            Bindings.when(model.turnProperty().isEqualTo(Owner.SECOND))
		            .then("-fx-background-color: cyan;")
		            .otherwise("-fx-background-color: red;"));
	        //System.out.println(model.getScore(model.turnProperty().get()).getValue());

	        firstCase.textProperty().bind(model.getScore(Owner.FIRST).asString("cases  par X : %d"));
            secondCase.textProperty().bind(model.getScore(Owner.SECOND).asString("cases par X : %d"));
            
         
         // Lier la visibilité du Label à l'état du jeu
            freeCase.visibleProperty().bind(model.gameOver().not());
            
            // Lier le texte du Label au nombre de cases libres
            freeCase.textProperty().bind(Bindings.format("%d cases libres", model.getFreeCells()));

            winnerTxtf.textProperty().bind(model.getEndOfGameMessage());
            winnerTxtf.visibleProperty().bind(model.gameOver());
            
            System.out.println(model.getScore(Owner.FIRST).getValue()+ " "+ model.getScore(Owner.SECOND).getValue());
	        
            if (model.getWinningSquare(row, column).get()) {
                // Si la case est gagnante, récupérez la case correspondante
                //TicTacToeSquare square = getSquareAt(i, j);
                // Appliquez un style différent aux cases gagnantes
                square.setStyle("-fx-font-size: 16pt; -fx-font-weight: bold;");
            }
            
            
	    } else {
	        // Le coup n'est pas légal, vous pouvez afficher un message d'erreur ou ignorer le clic.
	    	
	    }
	}
	
	
	
	 @FXML
	    private void handleRestartButton(ActionEvent event) {
	        
		 	
	        model.restart();
	     // Lier le texte du Label au nombre de cases libres
            freeCase.textProperty().bind(Bindings.format("%d cases libres", model.getFreeCells()));
	        this.initialize(null, null);
	        //System.out.println("vcx");
	    }
	 

}
