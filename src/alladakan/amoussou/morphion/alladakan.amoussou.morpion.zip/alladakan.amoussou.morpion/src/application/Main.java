package application;
	
import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;


public class Main extends Application {
	
//	//Initialisation des éléments de la vue fxml
//		@FXML private TextField essai;
//		
//		@FXML private Button resartButton;
//		@FXML private GridPane gridPane;
		
	@Override
	public void start(Stage primaryStage/*Fénétre de prmier niveau*/) {
		try {
			
			
			// Charger le fichier FXML
            Parent root = FXMLLoader.load(getClass().getResource("vue.fxml"));
            //récupérez le GridPane à l'aide de la méthode lookup() en utilisant l'identifiant spécifié dans votre fichier FXML.
            //Si on le fait pas, il y aura une erreur de chargement du gridPane parcequ'il est vide
            GridPane gridPane = (GridPane) root.lookup("#gridPane");
            gridPane.setStyle("-fx-grid-lines-visible: true;");

            // Créer une nouvelle scène
            Scene scene = new Scene(root);

            // Appliquer la feuille de style CSS à la scène si nécessaire
            scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
            
            // Configurer le stage (la fenêtre principale)
            primaryStage.setTitle("Mon Morpion");
            primaryStage.setScene(scene);
            primaryStage.show();
		} catch(Exception e) {
			System.out.println("Une erreur est survenue");
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		launch(args);//Cette méthode lance la fonction start qui est indispensable
	}
}
